var dummy=1;
